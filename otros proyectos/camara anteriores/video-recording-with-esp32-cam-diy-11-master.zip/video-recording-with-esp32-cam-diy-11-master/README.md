# video-recording-with-esp32-cam-diy-11
YouTube Video: https://youtu.be/lc_gXfkoRZo

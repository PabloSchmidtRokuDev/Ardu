```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/get-started/os/index.md
```
# (RT)OS

```eval_rst

.. toctree::
   :maxdepth: 2

   nuttx
   rt-thread
   freertos
   zephyr
```


```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/overview/renderers/sw.md
```
# Software renderer

TODO

